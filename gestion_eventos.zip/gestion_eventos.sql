drop database if exists gestion_usuarios;
create database gestion_usuarios;
use gestion_usuarios;

#Tabla para usuarios
CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(20),
    email VARCHAR(25) UNIQUE,
    contraseña VARCHAR(25)
);
#Tabla para organizadores
CREATE TABLE organizadores (
    id_organizadores INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25),
    contacto VARCHAR(25)
);
#Tabla para categorías de eventos
CREATE TABLE categoria_eventos (
    id_categorias INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(25)
);
#Tabla para eventos
CREATE TABLE eventos (
    id_evento INT AUTO_INCREMENT PRIMARY KEY,
    id_categorias int,
    id_organizadores int,
    nombre VARCHAR(25),
    fecha DATE,
    duracion INT,
    ubicacion VARCHAR(25),
    FOREIGN KEY (id_categorias) REFERENCES categoria_eventos(id_categorias), 
    FOREIGN KEY (id_organizadores) REFERENCES organizadores(id_organizadores)
);
#Tabla para inscripciones de usuarios en eventos
CREATE TABLE incripciones (
    id_inscripcion INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    id_evento INT,
    f_inscripcion DATE,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
    FOREIGN KEY (id_evento) REFERENCES eventos(id_evento)
);
#Tabla para ubicaciones de eventos presenciales
CREATE TABLE ubicaciones (
    id_ubicaciones INT AUTO_INCREMENT PRIMARY KEY,
    tipo INT, 
    direccion VARCHAR(25),
    FOREIGN KEY (id_evento) REFERENCES eventos(id_evento)
);
